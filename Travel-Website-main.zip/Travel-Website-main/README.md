# Travelmania
                                                
 Introduction :-
 Welcome to Travelmania website is an online travelling website containing all your prefrences and tours & packages and its a site which connect you to your best tour package site as and online best package locater for you and contains a login page , a website were you can visit and a booking page. So,please visit our site
 
 Login page :-
 Our login page contain a signup page which is connect to ur realtime database which helps us to let you login through our sign in side .
 step 1 :- Enter to our sign up page through our link 
 step 2 :- Sign up with your email,username,password 
 step 3 :- then enter to sign in side and enter your email and password to enter our site
 
 Travelmania page
 Its a travel site where you can locate best packages and hotels of your prefrences.
 
 Booking page :-
 at the right corner of our travel page we have a book option on a navbar
 Step 1 :-  Click on  right corner of navbar book option
 step 2 :- here you will see our booking page.enter your details
 step 3 :- Enter fields like where to go and from where to go ,date of arrival and date of leaving ,payments & Number of guests.
 
 Firebase :-
 we have connected our site to fire base features such as realtime database ,Login page is connected to realtime database and we have authenticated our site with email where we can find your emails where your bookings can be send . we have hosted our site .
 
 Hosting Site :- https://login-92833.web.app/
         
 
login
![login](https://user-images.githubusercontent.com/93962702/177335024-c951c7d4-d81d-4529-8eec-39732053b4d3.png)
![login1](https://user-images.githubusercontent.com/93962702/177335053-de40698b-b71f-40f3-97ae-1815968848a3.png)
Travelmania
![travel1](https://user-images.githubusercontent.com/93962702/177335237-f6a93025-4213-4cd9-9460-84447cc18cb0.png)
![travel2](https://user-images.githubusercontent.com/93962702/177335158-d57e217e-d141-4c35-bcdd-1fe02f8b2b05.png)
![travel3](https://user-images.githubusercontent.com/93962702/177335308-c06b5e15-f88f-4cc6-bf50-d19a53922ffa.png)
![travel4](https://user-images.githubusercontent.com/93962702/177335345-ab74c997-b30d-4b0f-8da7-0b649db9204d.png)
![travel5](https://user-images.githubusercontent.com/93962702/177335373-081f21ab-6dfc-4ff9-8d59-ab8d90df4a03.png)
![travel6](https://user-images.githubusercontent.com/93962702/177335402-61a3425c-0c04-43ec-9396-1466c387199c.png)
Firebase
![firebase1](https://user-images.githubusercontent.com/93962702/177335439-3d9769fd-95ae-47ff-a1ff-05953b7b50f4.png)
![firebase2](https://user-images.githubusercontent.com/93962702/177335464-c6c5e1b9-c76a-486a-97eb-bdaaf4daea51.png)
![firebase3](https://user-images.githubusercontent.com/93962702/177335491-3ce8a12d-764f-4395-9753-0706f36b89c5.png)
![hosting](https://user-images.githubusercontent.com/93962702/177335507-20c9c6b2-4f40-41f3-8de3-0f9d72e59ff5.png)
